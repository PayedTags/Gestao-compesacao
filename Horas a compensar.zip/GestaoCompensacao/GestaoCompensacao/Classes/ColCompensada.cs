﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;

namespace GestaoCompensacao.Classes
{
    public class ColCompensada : Collection<Compensada>
    {
        public new bool Add(Compensada compensada)
        {
            foreach (Compensada compensado in this)
            {
                if(compensado == compensada)
                {
                    return false;
                }
            }
            base.Add(compensada);
            return true;
        }

    }
}
