﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestaoCompensacao.Classes
{
    public class Aluno
    {
        public ColHorasCompensar aCompensar = new ColHorasCompensar();
        public ColCompensada jaCompensada = new ColCompensada();

        public int numero;
        public string nome;
        public string codigo;

        public Aluno(int numero, string nome, string codigo)
        {
            this.numero = numero;
            this.nome = nome;
            this.codigo = codigo;
            
        }

        //colHoras horas = new colHoras();
        //horas.Eliminar horas
    }
}
