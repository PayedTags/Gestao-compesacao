﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestaoCompensacao.Classes
{
    public class Compensada
    { 
        public Siglas sigla; // int pq o prof disse para usar um enum
        public int trimeste;
        public DateTime data;
        public DateTime horaInicial;
        public DateTime horaFinal;

    }
}
