﻿namespace GestaoCompensacao
{
    partial class CriarCadAluno
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbxCodigo = new System.Windows.Forms.TextBox();
            this.lbCodigo = new System.Windows.Forms.Label();
            this.lbTurma = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tbxNome = new System.Windows.Forms.TextBox();
            this.bttCriar = new System.Windows.Forms.Button();
            this.tbxTurma = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // tbxCodigo
            // 
            this.tbxCodigo.Location = new System.Drawing.Point(71, 12);
            this.tbxCodigo.Name = "tbxCodigo";
            this.tbxCodigo.Size = new System.Drawing.Size(66, 20);
            this.tbxCodigo.TabIndex = 0;
            this.tbxCodigo.TextChanged += new System.EventHandler(this.tbxCodigo_TextChanged);
            this.tbxCodigo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbxCodigo_KeyPress);
            // 
            // lbCodigo
            // 
            this.lbCodigo.AutoSize = true;
            this.lbCodigo.Location = new System.Drawing.Point(12, 15);
            this.lbCodigo.Name = "lbCodigo";
            this.lbCodigo.Size = new System.Drawing.Size(46, 13);
            this.lbCodigo.TabIndex = 1;
            this.lbCodigo.Text = "Codigo: ";
            // 
            // lbTurma
            // 
            this.lbTurma.AutoSize = true;
            this.lbTurma.Location = new System.Drawing.Point(12, 52);
            this.lbTurma.Name = "lbTurma";
            this.lbTurma.Size = new System.Drawing.Size(43, 13);
            this.lbTurma.TabIndex = 2;
            this.lbTurma.Text = "Turma: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 95);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Nome: ";
            // 
            // tbxNome
            // 
            this.tbxNome.Location = new System.Drawing.Point(71, 92);
            this.tbxNome.Name = "tbxNome";
            this.tbxNome.Size = new System.Drawing.Size(284, 20);
            this.tbxNome.TabIndex = 5;
            this.tbxNome.TextChanged += new System.EventHandler(this.tbxNome_TextChanged);
            this.tbxNome.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbxNome_KeyPress);
            // 
            // bttCriar
            // 
            this.bttCriar.Enabled = false;
            this.bttCriar.Location = new System.Drawing.Point(280, 119);
            this.bttCriar.Name = "bttCriar";
            this.bttCriar.Size = new System.Drawing.Size(75, 23);
            this.bttCriar.TabIndex = 6;
            this.bttCriar.Text = "Criar";
            this.bttCriar.UseVisualStyleBackColor = true;
            this.bttCriar.Click += new System.EventHandler(this.bttCriar_Click);
            // 
            // tbxTurma
            // 
            this.tbxTurma.Location = new System.Drawing.Point(71, 52);
            this.tbxTurma.Name = "tbxTurma";
            this.tbxTurma.Size = new System.Drawing.Size(122, 20);
            this.tbxTurma.TabIndex = 7;
            this.tbxTurma.TextChanged += new System.EventHandler(this.tbxTurma_TextChanged);
            this.tbxTurma.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbxTurma_KeyPress);
            // 
            // CriarCadAluno
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(367, 154);
            this.Controls.Add(this.tbxTurma);
            this.Controls.Add(this.bttCriar);
            this.Controls.Add(this.tbxNome);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lbTurma);
            this.Controls.Add(this.lbCodigo);
            this.Controls.Add(this.tbxCodigo);
            this.Name = "CriarCadAluno";
            this.Text = "CriarCadAluno";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CriarCadAluno_FormClosing);
            this.Load += new System.EventHandler(this.CriarCadAluno_Load);
            this.Leave += new System.EventHandler(this.CriarCadAluno_Leave);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbxCodigo;
        private System.Windows.Forms.Label lbCodigo;
        private System.Windows.Forms.Label lbTurma;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbxNome;
        private System.Windows.Forms.Button bttCriar;
        private System.Windows.Forms.TextBox tbxTurma;
    }
}