﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GestaoCompensacao.Classes;
namespace GestaoCompensacao
{
    public partial class ApagarAluno : Form
    {
        public ApagarAluno()
        {
            InitializeComponent();
        }

        private void ApagarAluno_Load(object sender, EventArgs e)
        {
            Form1.Turma.CarregarTurmaAluno(tview_TurmaAluno);
        }

        private void btn_Apagar_Click(object sender, EventArgs e)
        {

            if (tview_TurmaAluno.SelectedNode != null)
            {
                Aluno aluno = Form1.Turma.ProcuraAluno(Convert.ToInt32(tview_TurmaAluno.SelectedNode.Text));
                if (aluno != null)
                {
                    Form1.Turma.RemoveAt(aluno.numero);
                    Form1.Turma.CarregarTurmaAluno(tview_TurmaAluno);
                }
            }

        }

    }
}
