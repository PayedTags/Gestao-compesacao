﻿namespace GestaoCompensacao
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.alunosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi_Criar = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi_Apagar = new System.Windows.Forms.ToolStripMenuItem();
            this.horasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi_Compensar = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi_Compensacao = new System.Windows.Forms.ToolStripMenuItem();
            this.ferramentasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi_HorasCompensar = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi_HorasCompensadas = new System.Windows.Forms.ToolStripMenuItem();
            this.lstView_Compensacoes = new System.Windows.Forms.ListView();
            this.nomeDoAluno = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.trimestre = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.siglaDaDisciplina = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.data = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.horaInicial = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.horaFinal = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.saldo = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.alunosToolStripMenuItem,
            this.horasToolStripMenuItem,
            this.ferramentasToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(725, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // alunosToolStripMenuItem
            // 
            this.alunosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmi_Criar,
            this.tsmi_Apagar});
            this.alunosToolStripMenuItem.Name = "alunosToolStripMenuItem";
            this.alunosToolStripMenuItem.Size = new System.Drawing.Size(56, 20);
            this.alunosToolStripMenuItem.Text = "Alunos";
            // 
            // tsmi_Criar
            // 
            this.tsmi_Criar.Name = "tsmi_Criar";
            this.tsmi_Criar.Size = new System.Drawing.Size(112, 22);
            this.tsmi_Criar.Text = "Criar";
            this.tsmi_Criar.Click += new System.EventHandler(this.tsmi_Criar_Click);
            // 
            // tsmi_Apagar
            // 
            this.tsmi_Apagar.Name = "tsmi_Apagar";
            this.tsmi_Apagar.Size = new System.Drawing.Size(112, 22);
            this.tsmi_Apagar.Text = "Apagar";
            this.tsmi_Apagar.Click += new System.EventHandler(this.tsmi_Apagar_Click);
            // 
            // horasToolStripMenuItem
            // 
            this.horasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmi_Compensar,
            this.tsmi_Compensacao});
            this.horasToolStripMenuItem.Name = "horasToolStripMenuItem";
            this.horasToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.horasToolStripMenuItem.Text = "Horas";
            // 
            // tsmi_Compensar
            // 
            this.tsmi_Compensar.Name = "tsmi_Compensar";
            this.tsmi_Compensar.Size = new System.Drawing.Size(180, 22);
            this.tsmi_Compensar.Text = "A Compensar";
            this.tsmi_Compensar.Click += new System.EventHandler(this.tsmi_Compensar_Click);
            // 
            // tsmi_Compensacao
            // 
            this.tsmi_Compensacao.Name = "tsmi_Compensacao";
            this.tsmi_Compensacao.Size = new System.Drawing.Size(180, 22);
            this.tsmi_Compensacao.Text = "Compensação";
            this.tsmi_Compensacao.Click += new System.EventHandler(this.tsmi_Compensacao_Click);
            // 
            // ferramentasToolStripMenuItem
            // 
            this.ferramentasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmi_HorasCompensar,
            this.tsmi_HorasCompensadas});
            this.ferramentasToolStripMenuItem.Name = "ferramentasToolStripMenuItem";
            this.ferramentasToolStripMenuItem.Size = new System.Drawing.Size(84, 20);
            this.ferramentasToolStripMenuItem.Text = "Ferramentas";
            // 
            // tsmi_HorasCompensar
            // 
            this.tsmi_HorasCompensar.Name = "tsmi_HorasCompensar";
            this.tsmi_HorasCompensar.Size = new System.Drawing.Size(183, 22);
            this.tsmi_HorasCompensar.Text = "Horas a Compensar";
            this.tsmi_HorasCompensar.Click += new System.EventHandler(this.tsmi_HorasCompensar_Click);
            // 
            // tsmi_HorasCompensadas
            // 
            this.tsmi_HorasCompensadas.Name = "tsmi_HorasCompensadas";
            this.tsmi_HorasCompensadas.Size = new System.Drawing.Size(183, 22);
            this.tsmi_HorasCompensadas.Text = "Horas Compensadas";
            // 
            // lstView_Compensacoes
            // 
            this.lstView_Compensacoes.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lstView_Compensacoes.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.nomeDoAluno,
            this.trimestre,
            this.siglaDaDisciplina,
            this.data,
            this.horaInicial,
            this.horaFinal,
            this.saldo});
            this.lstView_Compensacoes.HideSelection = false;
            this.lstView_Compensacoes.Location = new System.Drawing.Point(12, 27);
            this.lstView_Compensacoes.MultiSelect = false;
            this.lstView_Compensacoes.Name = "lstView_Compensacoes";
            this.lstView_Compensacoes.Size = new System.Drawing.Size(701, 396);
            this.lstView_Compensacoes.TabIndex = 2;
            this.lstView_Compensacoes.UseCompatibleStateImageBehavior = false;
            this.lstView_Compensacoes.View = System.Windows.Forms.View.Details;
            // 
            // nomeDoAluno
            // 
            this.nomeDoAluno.Text = " Nome do/a aluno/a";
            this.nomeDoAluno.Width = 114;
            // 
            // trimestre
            // 
            this.trimestre.Text = "Trimestre";
            this.trimestre.Width = 58;
            // 
            // siglaDaDisciplina
            // 
            this.siglaDaDisciplina.Text = "Sigla da disciplina";
            this.siglaDaDisciplina.Width = 102;
            // 
            // data
            // 
            this.data.Text = "Data";
            this.data.Width = 41;
            // 
            // horaInicial
            // 
            this.horaInicial.Text = "Hora inicial";
            this.horaInicial.Width = 75;
            // 
            // horaFinal
            // 
            this.horaFinal.Text = "Hora final";
            this.horaFinal.Width = 71;
            // 
            // saldo
            // 
            this.saldo.Text = "Saldo";
            this.saldo.Width = 48;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(725, 435);
            this.Controls.Add(this.lstView_Compensacoes);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Activated += new System.EventHandler(this.Form1_Activated);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Enter += new System.EventHandler(this.Form1_Enter);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem alunosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tsmi_Criar;
        private System.Windows.Forms.ToolStripMenuItem horasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ferramentasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tsmi_Apagar;
        private System.Windows.Forms.ToolStripMenuItem tsmi_Compensar;
        private System.Windows.Forms.ToolStripMenuItem tsmi_Compensacao;
        private System.Windows.Forms.ToolStripMenuItem tsmi_HorasCompensar;
        private System.Windows.Forms.ToolStripMenuItem tsmi_HorasCompensadas;
        private System.Windows.Forms.ColumnHeader nomeDoAluno;
        private System.Windows.Forms.ColumnHeader trimestre;
        private System.Windows.Forms.ColumnHeader siglaDaDisciplina;
        private System.Windows.Forms.ColumnHeader data;
        private System.Windows.Forms.ColumnHeader horaInicial;
        private System.Windows.Forms.ColumnHeader horaFinal;
        private System.Windows.Forms.ColumnHeader saldo;
        public System.Windows.Forms.ListView lstView_Compensacoes;
    }
}

