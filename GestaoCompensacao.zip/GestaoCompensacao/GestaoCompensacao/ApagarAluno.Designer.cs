﻿namespace GestaoCompensacao
{
    partial class ApagarAluno
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tview_TurmaAluno = new System.Windows.Forms.TreeView();
            this.btn_Apagar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tview_TurmaAluno
            // 
            this.tview_TurmaAluno.Location = new System.Drawing.Point(12, 12);
            this.tview_TurmaAluno.Name = "tview_TurmaAluno";
            this.tview_TurmaAluno.Size = new System.Drawing.Size(506, 392);
            this.tview_TurmaAluno.TabIndex = 0;
            // 
            // btn_Apagar
            // 
            this.btn_Apagar.Location = new System.Drawing.Point(228, 410);
            this.btn_Apagar.Name = "btn_Apagar";
            this.btn_Apagar.Size = new System.Drawing.Size(75, 23);
            this.btn_Apagar.TabIndex = 1;
            this.btn_Apagar.Text = "Apagar";
            this.btn_Apagar.UseVisualStyleBackColor = true;
            this.btn_Apagar.Click += new System.EventHandler(this.btn_Apagar_Click);
            // 
            // ApagarAluno
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(530, 444);
            this.Controls.Add(this.btn_Apagar);
            this.Controls.Add(this.tview_TurmaAluno);
            this.Name = "ApagarAluno";
            this.Text = "ApagarAluno";
            this.Load += new System.EventHandler(this.ApagarAluno_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TreeView tview_TurmaAluno;
        private System.Windows.Forms.Button btn_Apagar;
    }
}