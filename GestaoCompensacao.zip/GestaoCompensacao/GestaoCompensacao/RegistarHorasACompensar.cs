﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GestaoCompensacao.Classes;

namespace GestaoCompensacao
{
    public partial class RegistarHorasACompensar : Form
    {
        public RegistarHorasACompensar()
        {
            InitializeComponent();
            carregarcbb();
            cbb_Disciplina.SelectedIndex = 0;
            cbb_Trimestre.SelectedIndex = 0;
            Form1.Turma.CarregarTurmaAluno(tview_TurmaAluno);
        }

        private void tbxTurma_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void lstviewTurma_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void bttInserir_Click(object sender, EventArgs e)
        {
            if (tview_TurmaAluno.SelectedNode.Text != "")
            {
                string sigla = cbb_Disciplina.Text;
                int trimestre = Convert.ToInt32(cbb_Trimestre.Text);
                double quantidade = Convert.ToDouble(numUpDown_Quantidade.Value);
                int numero = Convert.ToInt32(tview_TurmaAluno.SelectedNode.Text);
                Aluno pessoa = Form1.Turma.ProcuraAluno(numero);
                if(pessoa.aCompensar.ExisteCompensa(sigla, trimestre) == null)
                {
                    Horas hora = new Horas(sigla, trimestre, quantidade);
                    pessoa.aCompensar.Add(hora);
                }
                else
                {
                    MessageBox.Show("Ja existe", "");
                }


            }
        }

        private void RegistarHorasACompensar_Load(object sender, EventArgs e)
        {

        }

        private void carregarcbb()
        {
            cbb_Disciplina.Items.Add("PT");
            cbb_Disciplina.Items.Add("FQ");
            cbb_Disciplina.Items.Add("ING");
            cbb_Disciplina.Items.Add("TIC");
            cbb_Disciplina.Items.Add("EF");
            cbb_Disciplina.Items.Add("AI");
            cbb_Disciplina.Items.Add("PSI");
            cbb_Disciplina.Items.Add("MAT");
            cbb_Disciplina.Items.Add("SO");
            cbb_Disciplina.Items.Add("AC");
            cbb_Disciplina.Items.Add("RC");

            cbb_Trimestre.Items.Add("1");
            cbb_Trimestre.Items.Add("2");
            cbb_Trimestre.Items.Add("3");
            cbb_Trimestre.Items.Add("4");
        }

        private void numUpDown_Quantidade_ValueChanged(object sender, EventArgs e)
        {
            if(numUpDown_Quantidade.Value <= 0)
            {
                numUpDown_Quantidade.Value = 1;
            }
        }
    }
}
