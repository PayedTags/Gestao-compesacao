﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GestaoCompensacao.Classes;

namespace GestaoCompensacao
{
    public partial class RegistarHorasACompensar : Form
    {
        public RegistarHorasACompensar()
        {
            InitializeComponent();
            LoadItems();
            carregarcbb();
            cbb_Disciplina.SelectedIndex = 0;
        }

        private void tbxTurma_TextChanged(object sender, EventArgs e)
        {
            if(tbx_Turma.Text != "")
            {
                for (int i = lstview_Turma.Items.Count - 1; i >= 0; i--)
                {
                    var item = lstview_Turma.Items[i].SubItems[1];
                    if (!item.Text.ToLower().Contains(tbx_Turma.Text.ToLower()))
                    {
                        lstview_Turma.Items[i].Remove();
                    }
                }
            }
            else
            {
                LoadItems();
            }
        }

        private void LoadItems()
        {
            string[] item = new string[3];
            ListViewItem itm;
            lstview_Turma.Items.Clear();
            for (int i = 0; i < Form1.Turma.Count; i++)
            {
                item[0] = Convert.ToString(Form1.Turma[i].numero);
                item[2] = Form1.Turma[i].nome;
                item[1] = Form1.Turma[i].codigo;
                itm = new ListViewItem(item);
                lstview_Turma.Items.Add(itm);
            }
        }

        private void tbxTurma_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void lstviewTurma_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void bttInserir_Click(object sender, EventArgs e)
        {
            if(lstview_Turma.SelectedIndices.Count == 1)
            {
                string sigla = cbb_Disciplina.Text;
                int trimeste = Convert.ToInt32(tbx_Trimestre.Text);
                double quantidade = Convert.ToDouble(numUpDown_Quantidade.Value);


                foreach (Aluno pessoa in Form1.Turma)
                {
                    if (lstview_Turma.SelectedItems[0].Text == Convert.ToString(pessoa.numero))
                    {
                        foreach (Horas horas in pessoa.aCompensar)
                        {
                            if (Convert.ToString(horas.sigla) == sigla && horas.trimeste == trimeste)
                            {
                                MessageBox.Show("Erro", "Nao da");
                                break;
                            }
                        }

                        Horas hora = new Horas(sigla, trimeste, quantidade);
                        pessoa.aCompensar.Add(hora);
                        LoadItems();
                        break;
                    }
                }


            }
            else
            {
                MessageBox.Show("Não foi encontrado nenhum item selecionado", "Seleção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }

        private void RegistarHorasACompensar_Load(object sender, EventArgs e)
        {

        }

        private void carregarcbb()
        {
            cbb_Disciplina.Items.Add("PT");
            cbb_Disciplina.Items.Add("FQ");
            cbb_Disciplina.Items.Add("ING");
            cbb_Disciplina.Items.Add("TIC");
            cbb_Disciplina.Items.Add("EF");
            cbb_Disciplina.Items.Add("AI");
            cbb_Disciplina.Items.Add("PSI");
            cbb_Disciplina.Items.Add("MAT");
            cbb_Disciplina.Items.Add("SO");
            cbb_Disciplina.Items.Add("AC");
            cbb_Disciplina.Items.Add("RC");
        }
    }
}
