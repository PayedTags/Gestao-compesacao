﻿using GestaoCompensacao.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestaoCompensacao
{
    public partial class RegistoHorasCompensadas : Form
    {
        public RegistoHorasCompensadas()
        {
            InitializeComponent();
            LoadItems();
            carregarcbb();
            cbb_Disciplina.SelectedIndex = 0;
        }

        private void RegistoHorasCompensadas_Load(object sender, EventArgs e)
        {

        }

        private void LoadItems()
        {
            string[] item = new string[3];
            ListViewItem itm;
            lstview_Turma.Items.Clear();
            for (int i = 0; i < Form1.Turma.Count; i++)
            {
                item[0] = Convert.ToString(Form1.Turma[i].numero);
                item[2] = Form1.Turma[i].nome;
                item[1] = Form1.Turma[i].codigo;
                itm = new ListViewItem(item);
                lstview_Turma.Items.Add(itm);
            }
        }

        private void dtp_HoraInicial_MouseDown_1(object sender, MouseEventArgs e)
        {

        }

        private void dtp_HoraFinal_MouseDown(object sender, MouseEventArgs e)
        {

        }

        private void bttInserir_Click(object sender, EventArgs e)
        {
            double horaCompensada = CompensadaMinutos();



            if(horaCompensada >= 30)
            {
                foreach(Aluno pessoa in Form1.Turma)
                {
                    if(Convert.ToString(pessoa.numero) == lstview_Turma.SelectedItems[0].Text)
                    {
                        if (pessoa.aCompensar.Count > 0)
                        {
                            foreach(Horas horas in pessoa.aCompensar)
                            {
                                if (cbb_Disciplina.Text == Convert.ToString(horas.sigla) && tbx_Trimestre.Text == Convert.ToString(horas.trimeste))
                                {
                                    int trimeste = Convert.ToInt32(tbx_Trimestre.Text);
                                    

                                    Compensada compensada = new Compensada(cbb_Disciplina.Text, Convert.ToInt32(tbx_Trimestre.Text), Convert.ToDateTime(dtp_data), Convert.ToDateTime(dtp_HoraInicial), Convert.ToDateTime(dtp_HoraFinal));
                                    pessoa.jaCompensada.Add(compensada);

                                    if (horaCompensada - horas.qtdCompensar * 60 == 0)
                                    {
                                        
                                    }

                                }
                            }
                        }
                        else 
                        {
                            MessageBox.Show("Não tem nehuma disciplina para compensar");
                        }

                    }
                    
                }
            }
            else
            {
                MessageBox.Show("A compensação tem que ter pelo menos 30 minutos", "Erro Hora", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private double CompensadaMinutos()
        {
            double hours = 0;
            double minutos = 0;
            hours = dtp_HoraFinal.Value.Hour - dtp_HoraInicial.Value.Hour;
            minutos = dtp_HoraFinal.Value.Minute - dtp_HoraInicial.Value.Minute;
            minutos += hours * 60;

            return minutos;

        }

        private void carregarcbb()
        {
            cbb_Disciplina.Items.Add("PT");
            cbb_Disciplina.Items.Add("FQ");
            cbb_Disciplina.Items.Add("ING");
            cbb_Disciplina.Items.Add("TIC");
            cbb_Disciplina.Items.Add("EF");
            cbb_Disciplina.Items.Add("AI");
            cbb_Disciplina.Items.Add("PSI");
            cbb_Disciplina.Items.Add("MAT");
            cbb_Disciplina.Items.Add("SO");
            cbb_Disciplina.Items.Add("AC");
            cbb_Disciplina.Items.Add("RC");
        }
    }
}
