﻿using GestaoCompensacao.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestaoCompensacao
{
    public partial class RegistoHorasCompensadas : Form
    {
        public RegistoHorasCompensadas()
        {
            InitializeComponent();
            carregarcbb();
            Form1.Turma.CarregarTurmaAluno(tview_TurmaAluno);
            cbb_Disciplina.SelectedIndex = 0;
            comboBox1.SelectedIndex = 0;
        }

        private void RegistoHorasCompensadas_Load(object sender, EventArgs e)
        {

        }

        private void dtp_HoraInicial_MouseDown_1(object sender, MouseEventArgs e)
        {

        }

        private void dtp_HoraFinal_MouseDown(object sender, MouseEventArgs e)
        {

        }

        private void bttInserir_Click(object sender, EventArgs e)
        {
            double horaCompensada = CompensadaMinutos();

            if (horaCompensada >= 30)
            {
                string disciplina = cbb_Disciplina.Text;
                int trimestre = Convert.ToInt32(comboBox1.Text);
                DateTime data = dtp_data.Value; 
                DateTime horaInicial = dtp_HoraInicial.Value;
                DateTime horaFinal = dtp_HoraFinal.Value ;
                int numero = Convert.ToInt32(tview_TurmaAluno.SelectedNode.Text);
                Aluno pessoa = Form1.Turma.ProcuraAluno(numero);
                if (pessoa.aCompensar.ExisteCompensa(disciplina, trimestre) == null)
                {
                    Compensada compensada = new Compensada(disciplina, trimestre, data, horaInicial, horaFinal);
                    pessoa.jaCompensada.Add(compensada);
                    pessoa.aCompensar.ReduzirHora(pessoa.aCompensar.ExisteCompensa(disciplina, trimestre), horaCompensada / 60);
                }
                else
                {
                    MessageBox.Show("Erro", "Diciplina");
                }
            }
            else
            {
                MessageBox.Show("A compensação tem que ter pelo menos 30 minutos", "Erro Hora", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private double CompensadaMinutos()
        {
            double hours = 0;
            double minutos = 0;
            hours = dtp_HoraFinal.Value.Hour - dtp_HoraInicial.Value.Hour;
            minutos = dtp_HoraFinal.Value.Minute - dtp_HoraInicial.Value.Minute;
            minutos += hours * 60;

            return minutos;

        }

        private void carregarcbb()
        {
            cbb_Disciplina.Items.Add("PT");
            cbb_Disciplina.Items.Add("FQ");
            cbb_Disciplina.Items.Add("ING");
            cbb_Disciplina.Items.Add("TIC");
            cbb_Disciplina.Items.Add("EF");
            cbb_Disciplina.Items.Add("AI");
            cbb_Disciplina.Items.Add("PSI");
            cbb_Disciplina.Items.Add("MAT");
            cbb_Disciplina.Items.Add("SO");
            cbb_Disciplina.Items.Add("AC");
            cbb_Disciplina.Items.Add("RC");

            comboBox1.Items.Add("1");
            comboBox1.Items.Add("2");
            comboBox1.Items.Add("3");
            comboBox1.Items.Add("4");
        }
    }
}
