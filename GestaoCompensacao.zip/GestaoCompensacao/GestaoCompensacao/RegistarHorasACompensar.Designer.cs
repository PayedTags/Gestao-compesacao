﻿namespace GestaoCompensacao
{
    partial class RegistarHorasACompensar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_Trimestre = new System.Windows.Forms.Label();
            this.lb_Quantidade = new System.Windows.Forms.Label();
            this.lb_Disciplina = new System.Windows.Forms.Label();
            this.cbb_Disciplina = new System.Windows.Forms.ComboBox();
            this.bttInserir = new System.Windows.Forms.Button();
            this.numUpDown_Quantidade = new System.Windows.Forms.NumericUpDown();
            this.cbb_Trimestre = new System.Windows.Forms.ComboBox();
            this.tview_TurmaAluno = new System.Windows.Forms.TreeView();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDown_Quantidade)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_Trimestre
            // 
            this.lb_Trimestre.AutoSize = true;
            this.lb_Trimestre.Location = new System.Drawing.Point(138, 9);
            this.lb_Trimestre.Name = "lb_Trimestre";
            this.lb_Trimestre.Size = new System.Drawing.Size(50, 13);
            this.lb_Trimestre.TabIndex = 7;
            this.lb_Trimestre.Text = "Trimestre";
            // 
            // lb_Quantidade
            // 
            this.lb_Quantidade.AutoSize = true;
            this.lb_Quantidade.Location = new System.Drawing.Point(210, 9);
            this.lb_Quantidade.Name = "lb_Quantidade";
            this.lb_Quantidade.Size = new System.Drawing.Size(170, 13);
            this.lb_Quantidade.TabIndex = 8;
            this.lb_Quantidade.Text = "Quantidade de horas a compensar";
            // 
            // lb_Disciplina
            // 
            this.lb_Disciplina.AutoSize = true;
            this.lb_Disciplina.Location = new System.Drawing.Point(13, 9);
            this.lb_Disciplina.Name = "lb_Disciplina";
            this.lb_Disciplina.Size = new System.Drawing.Size(52, 13);
            this.lb_Disciplina.TabIndex = 10;
            this.lb_Disciplina.Text = "Disciplina";
            // 
            // cbb_Disciplina
            // 
            this.cbb_Disciplina.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbb_Disciplina.FormattingEnabled = true;
            this.cbb_Disciplina.Location = new System.Drawing.Point(16, 25);
            this.cbb_Disciplina.Name = "cbb_Disciplina";
            this.cbb_Disciplina.Size = new System.Drawing.Size(103, 21);
            this.cbb_Disciplina.TabIndex = 13;
            // 
            // bttInserir
            // 
            this.bttInserir.Location = new System.Drawing.Point(258, 475);
            this.bttInserir.Name = "bttInserir";
            this.bttInserir.Size = new System.Drawing.Size(86, 22);
            this.bttInserir.TabIndex = 1;
            this.bttInserir.Text = "Inserir";
            this.bttInserir.UseVisualStyleBackColor = true;
            this.bttInserir.Click += new System.EventHandler(this.bttInserir_Click);
            // 
            // numUpDown_Quantidade
            // 
            this.numUpDown_Quantidade.Location = new System.Drawing.Point(213, 25);
            this.numUpDown_Quantidade.Name = "numUpDown_Quantidade";
            this.numUpDown_Quantidade.Size = new System.Drawing.Size(46, 20);
            this.numUpDown_Quantidade.TabIndex = 12;
            this.numUpDown_Quantidade.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numUpDown_Quantidade.ValueChanged += new System.EventHandler(this.numUpDown_Quantidade_ValueChanged);
            // 
            // cbb_Trimestre
            // 
            this.cbb_Trimestre.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbb_Trimestre.FormattingEnabled = true;
            this.cbb_Trimestre.Location = new System.Drawing.Point(141, 25);
            this.cbb_Trimestre.Name = "cbb_Trimestre";
            this.cbb_Trimestre.Size = new System.Drawing.Size(47, 21);
            this.cbb_Trimestre.TabIndex = 14;
            // 
            // tview_TurmaAluno
            // 
            this.tview_TurmaAluno.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tview_TurmaAluno.Location = new System.Drawing.Point(16, 52);
            this.tview_TurmaAluno.Name = "tview_TurmaAluno";
            this.tview_TurmaAluno.Size = new System.Drawing.Size(572, 417);
            this.tview_TurmaAluno.TabIndex = 15;
            // 
            // RegistarHorasACompensar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(610, 509);
            this.Controls.Add(this.tview_TurmaAluno);
            this.Controls.Add(this.cbb_Trimestre);
            this.Controls.Add(this.cbb_Disciplina);
            this.Controls.Add(this.numUpDown_Quantidade);
            this.Controls.Add(this.lb_Disciplina);
            this.Controls.Add(this.lb_Quantidade);
            this.Controls.Add(this.lb_Trimestre);
            this.Controls.Add(this.bttInserir);
            this.Name = "RegistarHorasACompensar";
            this.Text = "RegistarHorasACompensar";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.RegistarHorasACompensar_FormClosing);
            this.Load += new System.EventHandler(this.RegistarHorasACompensar_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numUpDown_Quantidade)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lb_Trimestre;
        private System.Windows.Forms.Label lb_Quantidade;
        private System.Windows.Forms.Label lb_Disciplina;
        private System.Windows.Forms.ComboBox cbb_Disciplina;
        private System.Windows.Forms.Button bttInserir;
        private System.Windows.Forms.NumericUpDown numUpDown_Quantidade;
        private System.Windows.Forms.ComboBox cbb_Trimestre;
        private System.Windows.Forms.TreeView tview_TurmaAluno;
    }
}