﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestaoCompensacao.Classes
{
    public enum Siglas
    {
        PT = 1,
        ING = 2,
        TIC = 3,
        EF = 4,
        AI = 5,
        FQ = 6,
        MAT = 7,
        PSI = 8,
        SO = 9,
        AC = 10,
        RC = 11,
    }
}
