﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestaoCompensacao.Classes
{
    public class Compensada
    { 
        public Siglas sigla; // int pq o prof disse para usar um enum
        public int trimeste;
        public DateTime data;
        public DateTime horaInicial;
        public DateTime horaFinal;

        public Compensada(string sigla, int trimeste, DateTime data, DateTime horainicial, DateTime horafinal)
        {
            #region siglas
            switch (sigla)
            {
                case "PT":
                    this.sigla = Siglas.PT;
                    break;
                case "ING":
                    this.sigla = Siglas.ING;
                    break;
                case "AC":
                    this.sigla = Siglas.AC;
                    break;
                case "AI":
                    this.sigla = Siglas.AI;
                    break;
                case "RC":
                    this.sigla = Siglas.RC;
                    break;
                case "PSI":
                    this.sigla = Siglas.PSI;
                    break;
                case "MAT":
                    this.sigla = Siglas.MAT;
                    break;
                case "SO":
                    this.sigla = Siglas.SO;
                    break;
                case "EF":
                    this.sigla = Siglas.EF;
                    break;
                case "FQ":
                    this.sigla = Siglas.FQ;
                    break;
                case "TIC":
                    this.sigla = Siglas.TIC;
                    break;
            }
            #endregion
            this.trimeste = trimeste;
            this.data = data;
            this.horaInicial = horainicial;
            this.horaFinal = horafinal;
        }
        
    }
}
