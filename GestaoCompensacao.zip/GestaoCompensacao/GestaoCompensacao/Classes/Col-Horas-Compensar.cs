﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;

namespace GestaoCompensacao.Classes
{
    public class ColHorasCompensar : Collection<Horas>
    {
        //public new bool Add(Horas horas)

        public new bool Add(Horas horas)
        {
            foreach (Horas horos in this)
            {
                if (horos == horas)
                {
                    return false;
                }
            }
            this.Add(horas);
            return true;
        }

        
       
    }
}
