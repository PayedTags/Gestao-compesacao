﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;

namespace GestaoCompensacao.Classes
{
    public class ColHorasCompensar : Collection<Horas>
    {
        //public new bool Add(Horas horas)

        public new bool Add(Horas horas)
        {
            foreach (Horas horos in this)
            {
                if (horos == horas)
                {
                    return false;
                }
            }
            base.Add(horas);
            return true;
        }

        public void ReduzirHora(Horas hora, double qtd)
        {
            int i;
            for (i = 0; i < this.Count; i++)
            {
                if (this[i] == hora)
                    break;
            }
            this[i].qtdCompensar -= qtd;
            if (this[i].qtdCompensar <= 0)
            {
                this.RemoveAt(i);
            }
            return;
        }

        public Horas ExisteCompensa(string sigla, int trimestre)
        {
            foreach (Horas hora in this)
            {
                if (Convert.ToString(hora.sigla) == sigla && hora.trimeste == trimestre)
                {
                    return hora;
                }
            }

            return null;
        }

        public double TotalDeHorasD(string sigla)
        {
            double total = 0;
            foreach (Horas hora in this)
            {
                if(Convert.ToString(hora.sigla) == sigla)
                {
                    total += hora.qtdCompensar;
                }
            }

            return total;
        }
    }
}
