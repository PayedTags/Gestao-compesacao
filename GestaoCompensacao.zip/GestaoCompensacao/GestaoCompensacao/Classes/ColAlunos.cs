﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using System.Windows.Forms;
namespace GestaoCompensacao.Classes
{
    public class ColAlunos : Collection<Aluno>
    {
        
        public new bool Add(Aluno aluno)
        {
            foreach(Aluno pessoa in this) // foreach para verificar se o numero e repetido
            {
                if(aluno.numero == pessoa.numero) // se o numero for repetido
                {
                    return false; // parar e devolver falso (havia numero repetido e nao foi adicionado aluno)
                }
            }
            base.Add(aluno);
            return true; // devolver true (foi adicionado aluno com sucesso)

            /* EXEMPLO DE USO
                Aluno aluno = new Aluno(180075, "Tiago", "TGPSI18/02");
                if(!Turma.Add(aluno)) (nao esquecer de por "!" para verificar se a operação falhou)
                    MessageBox.Show("Erro, já ha um aluno com esse numero", "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
            */
        }

        public Aluno ProcuraAluno(int numero)
        {
            foreach(Aluno pessoa in this)
            {
                if (numero == pessoa.numero)
                    return pessoa;
            }
            return null;
        }

        public new bool RemoveAt(int numero)
        {

            int temp = -1; // variavel usada para ver se existe um aluno com o numero especificado
            for (int i = 0; i < this.Count; i++)
            {
                if (this[i].numero == numero)
                    temp = i;
            }
            if (temp == -1) // caso nao houve algum numero identico, devolver falso (nao houve aluno eliminado com sucesso)
                return false;

            base.RemoveAt(temp);
            return true; // devolver true (caso foi eliminado com sucesso)

            /* EXEMPLO DE USO
                if(!Turma.RemoveAt(idx)) (nao esquecer de por "!" para verificar se a operação falhou)
                    MessageBox.Show("Erro, nao ha nenhum aluno com esse numero", "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
                idx = index
            */
        }
        

        public string[] CodigoTurmas() //buscar todas turmas existentes
        {
            string[] codigoTurmas;
            codigoTurmas = new string[100];
            int qtdTurmas = 0;
            bool adicionado;
            for (int i = 0; i < this.Count; i++)
            {
                adicionado = false;
                for (int idx = 0; idx < qtdTurmas + 1; idx++)
                {
                    if (this[i].codigo == codigoTurmas[idx])
                    {
                        adicionado = false;
                        break;
                    }

                    adicionado = true;
                }
                if (adicionado)
                {
                    codigoTurmas[qtdTurmas] = this[i].codigo;
                    qtdTurmas++;
                }
            }
            return codigoTurmas;
        }

        public int[] AlunosDaTurma(string turma) //buscar alunos de uma turma
        {
            int[] indexes = new int[this.Count];
            int qtd = 0;
            for (int i = 0; i < indexes.Length; i++)
            {
                if (this[i].codigo == turma) // se for da mesma turma que estiver a procura, adicionar o idx ao array
                {
                    indexes[qtd] = i;
                    qtd++;
                }
            }
            return indexes; //um array com todos os idxs dos alunos da turma que procurou
        }

        public bool EliminarHoras(Horas horas, DateTime horaInicial, DateTime horaFim, DateTime data, int trimestre)
        {
            foreach(Aluno pessoa in this)
            {
                for (int i = 0; i < pessoa.aCompensar.Count; i++)
                {
                    if (horas == pessoa.aCompensar[i])
                    {
                        Compensada compensada = new Compensada(Convert.ToString(pessoa.aCompensar[i].sigla), trimestre, data, horaInicial, horaFim);
                        pessoa.jaCompensada[pessoa.jaCompensada.Count] = compensada;
                        pessoa.aCompensar[i].RemoveAt(i);

                        return true;
                    }
                }
            }
            
            return false;
        }

        public void CarregarTurmaAluno(TreeView tview)
        {
            tview.Nodes.Clear();
            string[] turmas = new string[100];
            turmas = this.CodigoTurmas();
            for (int i = 0; i < this.Count; i++)
            {
                TreeNode turma = new TreeNode(turmas[i]);
                tview.Nodes.Add(turma);

                foreach (TreeNode TurmaExistetne in tview.Nodes)
                {
                    int[] alunos = new int[Form1.Turma.Count];
                    alunos = Form1.Turma.AlunosDaTurma(turma.Text);
                    for (int idx = 0; alunos[idx] > alunos[0] || idx == 0; idx++)
                    {
                        turma.Nodes.Add(Form1.Turma[alunos[idx]].numero.ToString());
                        if (idx + 1 == Form1.Turma.Count)
                            break;
                    }
                }

            }
        }
    }
}
