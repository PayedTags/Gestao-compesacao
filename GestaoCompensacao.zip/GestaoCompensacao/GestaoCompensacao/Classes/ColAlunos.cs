﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;

namespace GestaoCompensacao.Classes
{
    public class ColAlunos : Collection<Aluno>
    {
        
        public new bool Add(Aluno aluno)
        {
            foreach(Aluno pessoa in this) // foreach para verificar se o numero e repetido
            {
                if(aluno.numero == pessoa.numero) // se o numero for repetido
                {
                    return false; // parar e devolver falso (havia numero repetido e nao foi adicionado aluno)
                }
            }
            base.Add(aluno);
            return true; // devolver true (foi adicionado aluno com sucesso)

            /* EXEMPLO DE USO
                Aluno aluno = new Aluno(180075, "Tiago", "TGPSI18/02");
                if(!Turma.Add(aluno)) (nao esquecer de por "!" para verificar se a operação falhou)
                    MessageBox.Show("Erro, já ha um aluno com esse numero", "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
            */
        }

        public new bool RemoveAt(int numero)
        {
            int temp = 0; // variavel usada para ver se existe um aluno com o numero especificado
            foreach(Aluno pessoa in this)
            {
                if(pessoa.numero == numero)
                {
                    temp++;
                    break;
                }
            }
            if (temp == 0) // caso nao houve algum numero identico, devolver falso (nao houve aluno eliminado com sucesso)
                return false;

            base.RemoveAt(numero);
            return true; // devolver true (caso foi eliminado com sucesso)

            /* EXEMPLO DE USO
                if(!Turma.RemoveAt(idx)) (nao esquecer de por "!" para verificar se a operação falhou)
                    MessageBox.Show("Erro, nao ha nenhum aluno com esse numero", "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
                idx = index
            */
        }



        public bool EliminarHoras(Horas horas, DateTime horaInicial, DateTime horaFim, DateTime data)
        {
            foreach(Aluno pessoa in this)
            {
                for (int i = 0; i < pessoa.aCompensar.Count; i++)
                {
                    if (horas == pessoa.aCompensar[i])
                    {
                        Compensada compensada = new Compensada();
                        compensada.sigla = pessoa.aCompensar[i].sigla;
                        compensada.data = data;
                        compensada.horaInicial = horaInicial;
                        compensada.horaFinal = horaFim;
                        pessoa.jaCompensada[pessoa.jaCompensada.Count] = compensada;
                        pessoa.aCompensar[i].RemoveAt(i);
                        
                        return true;
                    }
                }
            }
            
            return false;
        }
    }
}
