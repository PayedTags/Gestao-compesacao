﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections.ObjectModel;
using GestaoCompensacao.Classes;

namespace GestaoCompensacao
{
    public partial class Form1 : Form
    {
        public ColAlunos Turma = new ColAlunos();
        
        
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void tsmi_Criar_Click(object sender, EventArgs e)
        {
            CriarCadAluno formCriarCadAluno = new CriarCadAluno();
            formCriarCadAluno.Show();
        }

        private void tsmi_Compensar_Click(object sender, EventArgs e)
        {
            CriarHorasCompensar formCriarHCompensar = new CriarHorasCompensar();
            formCriarHCompensar.Show();
        }
    }
}
