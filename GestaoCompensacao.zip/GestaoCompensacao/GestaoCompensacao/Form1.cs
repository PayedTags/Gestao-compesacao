﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections.ObjectModel;
using GestaoCompensacao.Classes;

namespace GestaoCompensacao
{
    public partial class Form1 : Form
    {
        public static ColAlunos Turma = new ColAlunos();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void tsmi_Criar_Click(object sender, EventArgs e)
        {
            CriarCadAluno formCriarCadAluno = new CriarCadAluno();
            formCriarCadAluno.Show();
        }

        private void tsmi_Compensar_Click(object sender, EventArgs e)
        {
            RegistarHorasACompensar formRegistarHorasACompensar = new RegistarHorasACompensar();
            formRegistarHorasACompensar.Show();
        }

        public void CarregarAlunos()
        {
            
            foreach (Aluno aluno in Turma)
            {
                lstView_Compensacoes.Items.Clear();
                if (aluno.aCompensar.Count > 0 || aluno.jaCompensada.Count > 0)
                {
                    if (aluno.jaCompensada.Count == 0 )
                    {
                        for (int i = 0; i < aluno.aCompensar.Count; i++)
                        {
                            
                            ListViewItem Pessoa = new ListViewItem();
                            Pessoa.Text = aluno.nome;
                            Pessoa.SubItems.Add(aluno.aCompensar[i].trimeste.ToString());
                            Pessoa.SubItems.Add(aluno.aCompensar[i].sigla.ToString());
                            Pessoa.SubItems.Add("");
                            Pessoa.SubItems.Add("");
                            Pessoa.SubItems.Add("");
                            Pessoa.SubItems.Add(aluno.aCompensar[i].qtdCompensar.ToString());
                            lstView_Compensacoes.Items.Add(Pessoa);
                        }

                    }
                    else
                    {
                        for (int i = 0; i < aluno.jaCompensada.Count; i++)
                        {

                            ListViewItem Pessoa = new ListViewItem();
                            Pessoa.Text = aluno.nome;
                            Pessoa.SubItems.Add(aluno.jaCompensada[i].trimeste.ToString());
                            Pessoa.SubItems.Add(aluno.jaCompensada[i].sigla.ToString());
                            Pessoa.SubItems.Add(aluno.jaCompensada[i].data.ToString());
                            Pessoa.SubItems.Add(aluno.jaCompensada[i].horaInicial.ToString());
                            Pessoa.SubItems.Add(aluno.jaCompensada[i].horaFinal.ToString());
                            Pessoa.SubItems.Add(aluno.aCompensar[i].qtdCompensar.ToString());
                            lstView_Compensacoes.Items.Add(Pessoa);
                        }

                    }

                }

            }

        }

        private void Form1_Enter(object sender, EventArgs e)
        {
            
        }

        private void Form1_Activated(object sender, EventArgs e)
        {
            CarregarAlunos();
        }

        private void tsmi_HorasCompensar_Click(object sender, EventArgs e)
        {
            double saldo = 0;
            double subt = 0;
            if (lstView_Compensacoes.SelectedIndices.Count == 1)
            {
                foreach (Aluno pessoa in Turma)
                {
                    if (lstView_Compensacoes.SelectedItems[0].Text == Convert.ToString(pessoa.nome))
                    {
                        for (int i = 0; i < pessoa.aCompensar.Count;  i++)
                        {
                            saldo += pessoa.aCompensar[i].qtdCompensar;
                        }

                        for (int i = 0; i < pessoa.jaCompensada.Count; i++)
                        {
                            subt += Convert.ToDouble(pessoa.jaCompensada[i].horaInicial - pessoa.jaCompensada[i].horaFinal);
                        }

                        saldo = saldo - subt;

                        MessageBox.Show("" + saldo, "Saldo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        break;
                    }
                }
            }

            else
            {
                MessageBox.Show("Não foi encontrado nenhum item selecionado", "Seleção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void tsmi_Compensacao_Click(object sender, EventArgs e)
        {
            RegistoHorasCompensadas formRegistoHorasCompensadas = new RegistoHorasCompensadas();
            formRegistoHorasCompensadas.Show();
        }

        private void tsmi_Apagar_Click(object sender, EventArgs e)
        {
            ApagarAluno formApagarAluno = new ApagarAluno();
            formApagarAluno.Show();
        }
    }
}
