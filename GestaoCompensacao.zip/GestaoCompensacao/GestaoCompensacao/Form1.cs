﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections.ObjectModel;
using GestaoCompensacao.Classes;
using System.Security;

namespace GestaoCompensacao
{
    public partial class Form1 : Form
    {
        public static ColAlunos Turma = new ColAlunos();
        List<string> personDet = new List<string>();
        public string nomes, trimestres, siglas, qtd, datas, hI, hF;
        public static bool verifStats = false;
        public Form1()
        {
            InitializeComponent();

            personDet.Add(nomes);
            personDet.Add(trimestres);
            personDet.Add(siglas);
            personDet.Add(datas);
            personDet.Add(hI);
            personDet.Add(hF);
            personDet.Add(qtd);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void tsmi_Criar_Click(object sender, EventArgs e)
        {
            CriarCadAluno formCriarCadAluno = new CriarCadAluno();
            formCriarCadAluno.Show();
        }

        private void tsmi_Compensar_Click(object sender, EventArgs e)
        {
            RegistarHorasACompensar formRegistarHorasACompensar = new RegistarHorasACompensar();
            formRegistarHorasACompensar.ShowDialog();
            for (int i = 0; i < formRegistarHorasACompensar.count; i++)
            {
                ListViewItem Pessoa = new ListViewItem();
                Pessoa.Text = formRegistarHorasACompensar.tudo[i][0];
                Pessoa.SubItems.Add(formRegistarHorasACompensar.tudo[i][1]);
                Pessoa.SubItems.Add(formRegistarHorasACompensar.tudo[i][2]);
                Pessoa.SubItems.Add(formRegistarHorasACompensar.tudo[i][3]);
                Pessoa.SubItems.Add(formRegistarHorasACompensar.tudo[i][4]);
                Pessoa.SubItems.Add(formRegistarHorasACompensar.tudo[i][5]);
                Pessoa.SubItems.Add(formRegistarHorasACompensar.tudo[i][6]);
                lstView_Compensacoes.Items.Add(Pessoa);
            }
        }


        private void Form1_Enter(object sender, EventArgs e)
        {
            
        }

        private void Form1_Activated(object sender, EventArgs e)
        {

        }

        private void tsmi_HorasCompensar_Click(object sender, EventArgs e)
        {
            double saldo = 0;
            double subt = 0;
            double[] Disciplinas = new double[11]; //0 = PT, 1 = FQ, 2 = TIC , 3 = ING, 4 = EF, 5 = AI, 6 = MAT, 7 = PSI , 8 = SO, 9 = AC, 10 = RC.

            if (lstView_Compensacoes.SelectedIndices.Count == 1)
            {
                foreach(Aluno pessoa in Turma)
                {
                    if (pessoa.nome == lstView_Compensacoes.SelectedItems[0].SubItems[0].Text)
                    {
                        foreach (ListViewItem aluno in lstView_Compensacoes.Items)
                        {
                            if (aluno.SubItems[2].Text == "PT")
                            {
                                if (aluno.SubItems[4].Text == "")
                                {
                                    saldo += Convert.ToDouble(aluno.SubItems[6].Text);
                                }
                                else
                                {
                                    Disciplinas[0] += Convert.ToDouble(aluno.SubItems[6].Text);
                                    subt += Convert.ToDouble(aluno.SubItems[6].Text);
                                }

                            }
                            if (aluno.SubItems[2].Text == "FQ")
                            {
                                if (aluno.SubItems[4].Text == "")
                                {
                                    saldo += Convert.ToDouble(aluno.SubItems[6].Text);
                                }
                                else
                                {
                                    Disciplinas[1] += Convert.ToDouble(aluno.SubItems[6].Text);
                                    subt += Convert.ToDouble(aluno.SubItems[6].Text);
                                }
                            }
                            if (aluno.SubItems[2].Text == "TIC")
                            {
                                if (aluno.SubItems[4].Text == "")
                                {
                                    saldo += Convert.ToDouble(aluno.SubItems[6].Text);
                                }
                                else
                                {
                                    Disciplinas[2] += Convert.ToDouble(aluno.SubItems[6].Text);
                                    subt += Convert.ToDouble(aluno.SubItems[6].Text);
                                }
                            }
                            if (aluno.SubItems[2].Text == "ING")
                            {
                                if (aluno.SubItems[4].Text == "")
                                {
                                    saldo += Convert.ToDouble(aluno.SubItems[6].Text);
                                }
                                else
                                {
                                    Disciplinas[3] += Convert.ToDouble(aluno.SubItems[6].Text);
                                    subt += Convert.ToDouble(aluno.SubItems[6].Text);
                                }
                            }
                            if (aluno.SubItems[2].Text == "EF")
                            {
                                if (aluno.SubItems[4].Text == "")
                                {
                                    saldo += Convert.ToDouble(aluno.SubItems[6].Text);
                                }
                                else
                                {
                                    Disciplinas[4] += Convert.ToDouble(aluno.SubItems[6].Text);
                                    subt += Convert.ToDouble(aluno.SubItems[6].Text);
                                }
                            }
                            if (aluno.SubItems[2].Text == "AI")
                            {
                                if (aluno.SubItems[4].Text == "")
                                {
                                    saldo += Convert.ToDouble(aluno.SubItems[6].Text);
                                }
                                else
                                {
                                    Disciplinas[5] += Convert.ToDouble(aluno.SubItems[6].Text);
                                    subt += Convert.ToDouble(aluno.SubItems[6].Text);
                                }
                            }
                            if (aluno.SubItems[2].Text == "MAT")
                            {
                                if (aluno.SubItems[4].Text == "")
                                {
                                    saldo += Convert.ToDouble(aluno.SubItems[6].Text);
                                }
                                else
                                {
                                    Disciplinas[6] += Convert.ToDouble(aluno.SubItems[6].Text);
                                    subt += Convert.ToDouble(aluno.SubItems[6].Text);
                                }
                            }
                            if (aluno.SubItems[2].Text == "PSI")
                            {
                                if (aluno.SubItems[4].Text == "")
                                {
                                    saldo += Convert.ToDouble(aluno.SubItems[6].Text);
                                }
                                else
                                {
                                    Disciplinas[7] += Convert.ToDouble(aluno.SubItems[6].Text);
                                    subt += Convert.ToDouble(aluno.SubItems[6].Text);
                                }
                            }
                            if (aluno.SubItems[2].Text == "SO")
                            {
                                if (aluno.SubItems[4].Text == "")
                                {
                                    saldo += Convert.ToDouble(aluno.SubItems[6].Text);
                                }
                                else
                                {
                                    Disciplinas[8] += Convert.ToDouble(aluno.SubItems[6].Text);
                                    subt += Convert.ToDouble(aluno.SubItems[6].Text);
                                }
                            }
                            if (aluno.SubItems[2].Text == "AC")
                            {
                                if (aluno.SubItems[4].Text == "")
                                {
                                    saldo += Convert.ToDouble(aluno.SubItems[6].Text);
                                }
                                else
                                {
                                    Disciplinas[9] += Convert.ToDouble(aluno.SubItems[6].Text);
                                    subt += Convert.ToDouble(aluno.SubItems[6].Text);
                                }
                            }
                            if (aluno.SubItems[2].Text == "RC")
                            {
                                if (aluno.SubItems[4].Text == "")
                                {
                                    saldo += Convert.ToDouble(aluno.SubItems[6].Text);
                                }
                                else
                                {
                                    Disciplinas[10] += Convert.ToDouble(aluno.SubItems[6].Text);
                                    subt += Convert.ToDouble(aluno.SubItems[6].Text);
                                }


                            }
                        }
                    }
                }
                saldo = saldo - subt;
                MessageBox.Show("Informação por disciplina\n" + "PT: " + Disciplinas[0].ToString() + "\nFQ: " + Disciplinas[1].ToString() +
                    "\nTIC: " + Disciplinas[2].ToString() + "\nING: " + Disciplinas[3].ToString() + "\nEF: " + Disciplinas[4].ToString() +
                    "\nAI: " + Disciplinas[5].ToString() + "\nMAT: " + Disciplinas[6].ToString() + "\nPSI: " + Disciplinas[7].ToString() + "\nSO: "+ Disciplinas[8].ToString() +
                    "\nAC" + Disciplinas[9].ToString() + "\nRC: " + Disciplinas[10].ToString() +"\nTotal: " + saldo, "Informações do Aluno " + lstView_Compensacoes.Items[0].SubItems[0].Text);
                //0 = PT, 1 = FQ, 2 = TIC , 3 = ING, 4 = EF, 5 = AI, 6 = MAT, 7 = PSI , 8 = SO, 9 = AC, 10 = RC.

            }
            else
            {
                MessageBox.Show("Não foi encontrado nenhum item selecionado", "Seleção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void tsmi_Compensacao_Click(object sender, EventArgs e)
        {
            RegistoHorasCompensadas formRegistoHorasCompensadas = new RegistoHorasCompensadas();
            formRegistoHorasCompensadas.ShowDialog();
            for (int i = 0; i < formRegistoHorasCompensadas.count; i++)
            {
                ListViewItem Pessoa = new ListViewItem();
                Pessoa.Text = formRegistoHorasCompensadas.tudo[i][0];
                Pessoa.SubItems.Add(formRegistoHorasCompensadas.tudo[i][1]);
                Pessoa.SubItems.Add(formRegistoHorasCompensadas.tudo[i][2]);
                Pessoa.SubItems.Add(formRegistoHorasCompensadas.tudo[i][3]);
                Pessoa.SubItems.Add(formRegistoHorasCompensadas.tudo[i][4]);
                Pessoa.SubItems.Add(formRegistoHorasCompensadas.tudo[i][5]);
                Pessoa.SubItems.Add(formRegistoHorasCompensadas.tudo[i][6]);
                lstView_Compensacoes.Items.Add(Pessoa);
            }
        }

        private void tsmi_Apagar_Click(object sender, EventArgs e)
        {
            ApagarAluno formApagarAluno = new ApagarAluno();
            formApagarAluno.Show();
        }
    }
}
