﻿namespace GestaoCompensacao
{
    partial class RegistoHorasCompensadas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbb_Disciplina = new System.Windows.Forms.ComboBox();
            this.lb_Disciplina = new System.Windows.Forms.Label();
            this.lb_Trimestre = new System.Windows.Forms.Label();
            this.lb_HoraInicial = new System.Windows.Forms.Label();
            this.lb_HoraFinal = new System.Windows.Forms.Label();
            this.dtp_HoraInicial = new System.Windows.Forms.DateTimePicker();
            this.dtp_HoraFinal = new System.Windows.Forms.DateTimePicker();
            this.bttInserir = new System.Windows.Forms.Button();
            this.dtp_data = new System.Windows.Forms.DateTimePicker();
            this.lb_data = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.tview_TurmaAluno = new System.Windows.Forms.TreeView();
            this.SuspendLayout();
            // 
            // cbb_Disciplina
            // 
            this.cbb_Disciplina.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbb_Disciplina.FormattingEnabled = true;
            this.cbb_Disciplina.Location = new System.Drawing.Point(14, 25);
            this.cbb_Disciplina.Name = "cbb_Disciplina";
            this.cbb_Disciplina.Size = new System.Drawing.Size(103, 21);
            this.cbb_Disciplina.TabIndex = 17;
            // 
            // lb_Disciplina
            // 
            this.lb_Disciplina.AutoSize = true;
            this.lb_Disciplina.Location = new System.Drawing.Point(11, 9);
            this.lb_Disciplina.Name = "lb_Disciplina";
            this.lb_Disciplina.Size = new System.Drawing.Size(52, 13);
            this.lb_Disciplina.TabIndex = 16;
            this.lb_Disciplina.Text = "Disciplina";
            // 
            // lb_Trimestre
            // 
            this.lb_Trimestre.AutoSize = true;
            this.lb_Trimestre.Location = new System.Drawing.Point(124, 9);
            this.lb_Trimestre.Name = "lb_Trimestre";
            this.lb_Trimestre.Size = new System.Drawing.Size(50, 13);
            this.lb_Trimestre.TabIndex = 15;
            this.lb_Trimestre.Text = "Trimestre";
            // 
            // lb_HoraInicial
            // 
            this.lb_HoraInicial.AutoSize = true;
            this.lb_HoraInicial.Location = new System.Drawing.Point(293, 9);
            this.lb_HoraInicial.Name = "lb_HoraInicial";
            this.lb_HoraInicial.Size = new System.Drawing.Size(72, 13);
            this.lb_HoraInicial.TabIndex = 20;
            this.lb_HoraInicial.Text = "Hora de inicio";
            // 
            // lb_HoraFinal
            // 
            this.lb_HoraFinal.AutoSize = true;
            this.lb_HoraFinal.Location = new System.Drawing.Point(371, 9);
            this.lb_HoraFinal.Name = "lb_HoraFinal";
            this.lb_HoraFinal.Size = new System.Drawing.Size(45, 13);
            this.lb_HoraFinal.TabIndex = 21;
            this.lb_HoraFinal.Text = "Termino";
            // 
            // dtp_HoraInicial
            // 
            this.dtp_HoraInicial.CustomFormat = "  ";
            this.dtp_HoraInicial.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtp_HoraInicial.Location = new System.Drawing.Point(296, 26);
            this.dtp_HoraInicial.Name = "dtp_HoraInicial";
            this.dtp_HoraInicial.ShowUpDown = true;
            this.dtp_HoraInicial.Size = new System.Drawing.Size(69, 20);
            this.dtp_HoraInicial.TabIndex = 22;
            this.dtp_HoraInicial.MouseDown += new System.Windows.Forms.MouseEventHandler(this.dtp_HoraInicial_MouseDown_1);
            // 
            // dtp_HoraFinal
            // 
            this.dtp_HoraFinal.CustomFormat = "  ";
            this.dtp_HoraFinal.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtp_HoraFinal.Location = new System.Drawing.Point(374, 26);
            this.dtp_HoraFinal.Name = "dtp_HoraFinal";
            this.dtp_HoraFinal.ShowUpDown = true;
            this.dtp_HoraFinal.Size = new System.Drawing.Size(66, 20);
            this.dtp_HoraFinal.TabIndex = 23;
            this.dtp_HoraFinal.MouseDown += new System.Windows.Forms.MouseEventHandler(this.dtp_HoraFinal_MouseDown);
            // 
            // bttInserir
            // 
            this.bttInserir.Location = new System.Drawing.Point(294, 457);
            this.bttInserir.Name = "bttInserir";
            this.bttInserir.Size = new System.Drawing.Size(90, 23);
            this.bttInserir.TabIndex = 24;
            this.bttInserir.Text = "Inserir";
            this.bttInserir.UseVisualStyleBackColor = true;
            this.bttInserir.Click += new System.EventHandler(this.bttInserir_Click);
            // 
            // dtp_data
            // 
            this.dtp_data.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_data.Location = new System.Drawing.Point(201, 25);
            this.dtp_data.Name = "dtp_data";
            this.dtp_data.Size = new System.Drawing.Size(75, 20);
            this.dtp_data.TabIndex = 25;
            // 
            // lb_data
            // 
            this.lb_data.AutoSize = true;
            this.lb_data.Location = new System.Drawing.Point(198, 9);
            this.lb_data.Name = "lb_data";
            this.lb_data.Size = new System.Drawing.Size(30, 13);
            this.lb_data.TabIndex = 26;
            this.lb_data.Text = "Data";
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(127, 26);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(47, 21);
            this.comboBox1.TabIndex = 27;
            // 
            // tview_TurmaAluno
            // 
            this.tview_TurmaAluno.Location = new System.Drawing.Point(12, 52);
            this.tview_TurmaAluno.Name = "tview_TurmaAluno";
            this.tview_TurmaAluno.Size = new System.Drawing.Size(649, 399);
            this.tview_TurmaAluno.TabIndex = 28;
            // 
            // RegistoHorasCompensadas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(674, 492);
            this.Controls.Add(this.tview_TurmaAluno);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.lb_data);
            this.Controls.Add(this.dtp_data);
            this.Controls.Add(this.bttInserir);
            this.Controls.Add(this.dtp_HoraFinal);
            this.Controls.Add(this.dtp_HoraInicial);
            this.Controls.Add(this.lb_HoraFinal);
            this.Controls.Add(this.lb_HoraInicial);
            this.Controls.Add(this.cbb_Disciplina);
            this.Controls.Add(this.lb_Disciplina);
            this.Controls.Add(this.lb_Trimestre);
            this.Name = "RegistoHorasCompensadas";
            this.Text = "RegistoHorasCompensadas";
            this.Load += new System.EventHandler(this.RegistoHorasCompensadas_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ComboBox cbb_Disciplina;
        private System.Windows.Forms.Label lb_Disciplina;
        private System.Windows.Forms.Label lb_Trimestre;
        private System.Windows.Forms.Label lb_HoraInicial;
        private System.Windows.Forms.Label lb_HoraFinal;
        private System.Windows.Forms.DateTimePicker dtp_HoraInicial;
        private System.Windows.Forms.DateTimePicker dtp_HoraFinal;
        private System.Windows.Forms.Button bttInserir;
        private System.Windows.Forms.DateTimePicker dtp_data;
        private System.Windows.Forms.Label lb_data;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TreeView tview_TurmaAluno;
    }
}