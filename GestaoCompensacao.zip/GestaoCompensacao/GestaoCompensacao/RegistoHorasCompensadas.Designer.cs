﻿namespace GestaoCompensacao
{
    partial class RegistoHorasCompensadas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstview_Turma = new System.Windows.Forms.ListView();
            this.Codigo = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.codigodaturma = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Nome = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tbx_Turma = new System.Windows.Forms.TextBox();
            this.lb_Turma = new System.Windows.Forms.Label();
            this.cbb_Disciplina = new System.Windows.Forms.ComboBox();
            this.lb_Disciplina = new System.Windows.Forms.Label();
            this.lb_Trimestre = new System.Windows.Forms.Label();
            this.lb_HoraInicial = new System.Windows.Forms.Label();
            this.lb_HoraFinal = new System.Windows.Forms.Label();
            this.tbx_Trimestre = new System.Windows.Forms.TextBox();
            this.dtp_HoraInicial = new System.Windows.Forms.DateTimePicker();
            this.dtp_HoraFinal = new System.Windows.Forms.DateTimePicker();
            this.bttInserir = new System.Windows.Forms.Button();
            this.dtp_data = new System.Windows.Forms.DateTimePicker();
            this.lb_data = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lstview_Turma
            // 
            this.lstview_Turma.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lstview_Turma.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Codigo,
            this.codigodaturma,
            this.Nome});
            this.lstview_Turma.HideSelection = false;
            this.lstview_Turma.Location = new System.Drawing.Point(12, 52);
            this.lstview_Turma.MultiSelect = false;
            this.lstview_Turma.Name = "lstview_Turma";
            this.lstview_Turma.Size = new System.Drawing.Size(778, 399);
            this.lstview_Turma.TabIndex = 3;
            this.lstview_Turma.UseCompatibleStateImageBehavior = false;
            this.lstview_Turma.View = System.Windows.Forms.View.Details;
            // 
            // Codigo
            // 
            this.Codigo.Text = "Codigo de aluno";
            this.Codigo.Width = 94;
            // 
            // codigodaturma
            // 
            this.codigodaturma.Text = "Turma";
            // 
            // Nome
            // 
            this.Nome.Text = "Nome";
            // 
            // tbx_Turma
            // 
            this.tbx_Turma.Location = new System.Drawing.Point(12, 26);
            this.tbx_Turma.Name = "tbx_Turma";
            this.tbx_Turma.Size = new System.Drawing.Size(100, 20);
            this.tbx_Turma.TabIndex = 7;
            // 
            // lb_Turma
            // 
            this.lb_Turma.AutoSize = true;
            this.lb_Turma.Location = new System.Drawing.Point(12, 9);
            this.lb_Turma.Name = "lb_Turma";
            this.lb_Turma.Size = new System.Drawing.Size(37, 13);
            this.lb_Turma.TabIndex = 6;
            this.lb_Turma.Text = "Turma";
            // 
            // cbb_Disciplina
            // 
            this.cbb_Disciplina.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbb_Disciplina.FormattingEnabled = true;
            this.cbb_Disciplina.Location = new System.Drawing.Point(235, 25);
            this.cbb_Disciplina.Name = "cbb_Disciplina";
            this.cbb_Disciplina.Size = new System.Drawing.Size(103, 21);
            this.cbb_Disciplina.TabIndex = 17;
            // 
            // lb_Disciplina
            // 
            this.lb_Disciplina.AutoSize = true;
            this.lb_Disciplina.Location = new System.Drawing.Point(232, 9);
            this.lb_Disciplina.Name = "lb_Disciplina";
            this.lb_Disciplina.Size = new System.Drawing.Size(52, 13);
            this.lb_Disciplina.TabIndex = 16;
            this.lb_Disciplina.Text = "Disciplina";
            // 
            // lb_Trimestre
            // 
            this.lb_Trimestre.AutoSize = true;
            this.lb_Trimestre.Location = new System.Drawing.Point(345, 9);
            this.lb_Trimestre.Name = "lb_Trimestre";
            this.lb_Trimestre.Size = new System.Drawing.Size(50, 13);
            this.lb_Trimestre.TabIndex = 15;
            this.lb_Trimestre.Text = "Trimestre";
            // 
            // lb_HoraInicial
            // 
            this.lb_HoraInicial.AutoSize = true;
            this.lb_HoraInicial.Location = new System.Drawing.Point(616, 9);
            this.lb_HoraInicial.Name = "lb_HoraInicial";
            this.lb_HoraInicial.Size = new System.Drawing.Size(72, 13);
            this.lb_HoraInicial.TabIndex = 20;
            this.lb_HoraInicial.Text = "Hora de inicio";
            // 
            // lb_HoraFinal
            // 
            this.lb_HoraFinal.AutoSize = true;
            this.lb_HoraFinal.Location = new System.Drawing.Point(694, 9);
            this.lb_HoraFinal.Name = "lb_HoraFinal";
            this.lb_HoraFinal.Size = new System.Drawing.Size(45, 13);
            this.lb_HoraFinal.TabIndex = 21;
            this.lb_HoraFinal.Text = "Termino";
            // 
            // tbx_Trimestre
            // 
            this.tbx_Trimestre.Location = new System.Drawing.Point(348, 25);
            this.tbx_Trimestre.Name = "tbx_Trimestre";
            this.tbx_Trimestre.Size = new System.Drawing.Size(100, 20);
            this.tbx_Trimestre.TabIndex = 14;
            // 
            // dtp_HoraInicial
            // 
            this.dtp_HoraInicial.CustomFormat = "  ";
            this.dtp_HoraInicial.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtp_HoraInicial.Location = new System.Drawing.Point(619, 26);
            this.dtp_HoraInicial.Name = "dtp_HoraInicial";
            this.dtp_HoraInicial.ShowUpDown = true;
            this.dtp_HoraInicial.Size = new System.Drawing.Size(69, 20);
            this.dtp_HoraInicial.TabIndex = 22;
            this.dtp_HoraInicial.MouseDown += new System.Windows.Forms.MouseEventHandler(this.dtp_HoraInicial_MouseDown_1);
            // 
            // dtp_HoraFinal
            // 
            this.dtp_HoraFinal.CustomFormat = "  ";
            this.dtp_HoraFinal.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtp_HoraFinal.Location = new System.Drawing.Point(697, 26);
            this.dtp_HoraFinal.Name = "dtp_HoraFinal";
            this.dtp_HoraFinal.ShowUpDown = true;
            this.dtp_HoraFinal.Size = new System.Drawing.Size(66, 20);
            this.dtp_HoraFinal.TabIndex = 23;
            this.dtp_HoraFinal.MouseDown += new System.Windows.Forms.MouseEventHandler(this.dtp_HoraFinal_MouseDown);
            // 
            // bttInserir
            // 
            this.bttInserir.Location = new System.Drawing.Point(700, 457);
            this.bttInserir.Name = "bttInserir";
            this.bttInserir.Size = new System.Drawing.Size(90, 23);
            this.bttInserir.TabIndex = 24;
            this.bttInserir.Text = "Inserir";
            this.bttInserir.UseVisualStyleBackColor = true;
            this.bttInserir.Click += new System.EventHandler(this.bttInserir_Click);
            // 
            // dtp_data
            // 
            this.dtp_data.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_data.Location = new System.Drawing.Point(477, 25);
            this.dtp_data.Name = "dtp_data";
            this.dtp_data.Size = new System.Drawing.Size(118, 20);
            this.dtp_data.TabIndex = 25;
            // 
            // lb_data
            // 
            this.lb_data.AutoSize = true;
            this.lb_data.Location = new System.Drawing.Point(474, 9);
            this.lb_data.Name = "lb_data";
            this.lb_data.Size = new System.Drawing.Size(30, 13);
            this.lb_data.TabIndex = 26;
            this.lb_data.Text = "Data";
            // 
            // RegistoHorasCompensadas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(802, 492);
            this.Controls.Add(this.lb_data);
            this.Controls.Add(this.dtp_data);
            this.Controls.Add(this.bttInserir);
            this.Controls.Add(this.dtp_HoraFinal);
            this.Controls.Add(this.dtp_HoraInicial);
            this.Controls.Add(this.lb_HoraFinal);
            this.Controls.Add(this.lb_HoraInicial);
            this.Controls.Add(this.cbb_Disciplina);
            this.Controls.Add(this.lb_Disciplina);
            this.Controls.Add(this.lb_Trimestre);
            this.Controls.Add(this.tbx_Trimestre);
            this.Controls.Add(this.tbx_Turma);
            this.Controls.Add(this.lb_Turma);
            this.Controls.Add(this.lstview_Turma);
            this.Name = "RegistoHorasCompensadas";
            this.Text = "RegistoHorasCompensadas";
            this.Load += new System.EventHandler(this.RegistoHorasCompensadas_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView lstview_Turma;
        private System.Windows.Forms.ColumnHeader Codigo;
        private System.Windows.Forms.ColumnHeader codigodaturma;
        private System.Windows.Forms.ColumnHeader Nome;
        private System.Windows.Forms.TextBox tbx_Turma;
        private System.Windows.Forms.Label lb_Turma;
        private System.Windows.Forms.ComboBox cbb_Disciplina;
        private System.Windows.Forms.Label lb_Disciplina;
        private System.Windows.Forms.Label lb_Trimestre;
        private System.Windows.Forms.Label lb_HoraInicial;
        private System.Windows.Forms.Label lb_HoraFinal;
        private System.Windows.Forms.TextBox tbx_Trimestre;
        private System.Windows.Forms.DateTimePicker dtp_HoraInicial;
        private System.Windows.Forms.DateTimePicker dtp_HoraFinal;
        private System.Windows.Forms.Button bttInserir;
        private System.Windows.Forms.DateTimePicker dtp_data;
        private System.Windows.Forms.Label lb_data;
    }
}