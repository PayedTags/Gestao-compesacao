﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GestaoCompensacao.Classes;

namespace GestaoCompensacao
{
    public partial class CriarCadAluno : Form
    {
        public CriarCadAluno()
        {
            InitializeComponent();
        }

        private void tbxCodigo_TextChanged(object sender, EventArgs e)
        {
            verifCriar();
        }

        private void tbxNome_TextChanged(object sender, EventArgs e)
        {
            verifCriar();
        }


        private void verifCriar()
        {
            if (tbxCodigo.Text != "" && tbxNome.Text != "" && tbxTurma.Text != "")
            {
                bttCriar.Enabled = true;
            }
            else
            {
                bttCriar.Enabled = false;
            }
        }

        private void bttCriar_Click(object sender, EventArgs e)
        {
            Aluno aluno = new Aluno(Convert.ToInt32(tbxCodigo.Text), tbxNome.Text, tbxTurma.Text);
            if (!Form1.Turma.Add(aluno))
                MessageBox.Show("Erro, esse número já existe", "Erro ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            tbxNome.Clear();
            tbxTurma.Clear();
            tbxCodigo.Clear();
        }

        private void tbxCodigo_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void tbxNome_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(char.IsLetter(e.KeyChar) || e.KeyChar == 8 || e.KeyChar == 32 || e.KeyChar == 45 )
                e.Handled = false;
            else
                e.Handled = true;
        }

        private void tbxTurma_TextChanged(object sender, EventArgs e)
        {
            verifCriar();
        }

        private void tbxTurma_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }

        private void CriarCadAluno_Load(object sender, EventArgs e)
        {

        }

        private void CriarCadAluno_Leave(object sender, EventArgs e)
        {

        }

        private void CriarCadAluno_FormClosing(object sender, FormClosingEventArgs e)
        {
            
        }
    }
}
