﻿namespace GestaoCompensacao
{
    partial class RegistarHorasACompensar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstview_Turma = new System.Windows.Forms.ListView();
            this.Codigo = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.codigodaturma = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Nome = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lb_Turma = new System.Windows.Forms.Label();
            this.tbx_Turma = new System.Windows.Forms.TextBox();
            this.tbx_Trimestre = new System.Windows.Forms.TextBox();
            this.lb_Trimestre = new System.Windows.Forms.Label();
            this.lb_Quantidade = new System.Windows.Forms.Label();
            this.lb_Disciplina = new System.Windows.Forms.Label();
            this.numUpDown_Quantidade = new System.Windows.Forms.NumericUpDown();
            this.cbb_Disciplina = new System.Windows.Forms.ComboBox();
            this.bttInserir = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDown_Quantidade)).BeginInit();
            this.SuspendLayout();
            // 
            // lstview_Turma
            // 
            this.lstview_Turma.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lstview_Turma.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Codigo,
            this.codigodaturma,
            this.Nome});
            this.lstview_Turma.Location = new System.Drawing.Point(12, 52);
            this.lstview_Turma.Name = "lstview_Turma";
            this.lstview_Turma.Size = new System.Drawing.Size(664, 403);
            this.lstview_Turma.TabIndex = 2;
            this.lstview_Turma.UseCompatibleStateImageBehavior = false;
            this.lstview_Turma.View = System.Windows.Forms.View.Details;
            this.lstview_Turma.SelectedIndexChanged += new System.EventHandler(this.lstviewTurma_SelectedIndexChanged);
            // 
            // Codigo
            // 
            this.Codigo.Text = "Codigo de aluno";
            this.Codigo.Width = 94;
            // 
            // codigodaturma
            // 
            this.codigodaturma.Text = "Turma";
            // 
            // Nome
            // 
            this.Nome.Text = "Nome";
            // 
            // lb_Turma
            // 
            this.lb_Turma.AutoSize = true;
            this.lb_Turma.Location = new System.Drawing.Point(12, 9);
            this.lb_Turma.Name = "lb_Turma";
            this.lb_Turma.Size = new System.Drawing.Size(37, 13);
            this.lb_Turma.TabIndex = 4;
            this.lb_Turma.Text = "Turma";
            // 
            // tbx_Turma
            // 
            this.tbx_Turma.Location = new System.Drawing.Point(12, 26);
            this.tbx_Turma.Name = "tbx_Turma";
            this.tbx_Turma.Size = new System.Drawing.Size(100, 20);
            this.tbx_Turma.TabIndex = 5;
            this.tbx_Turma.TextChanged += new System.EventHandler(this.tbxTurma_TextChanged);
            this.tbx_Turma.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbxTurma_KeyPress);
            // 
            // tbx_Trimestre
            // 
            this.tbx_Trimestre.Location = new System.Drawing.Point(361, 25);
            this.tbx_Trimestre.Name = "tbx_Trimestre";
            this.tbx_Trimestre.Size = new System.Drawing.Size(100, 20);
            this.tbx_Trimestre.TabIndex = 6;
            // 
            // lb_Trimestre
            // 
            this.lb_Trimestre.AutoSize = true;
            this.lb_Trimestre.Location = new System.Drawing.Point(358, 9);
            this.lb_Trimestre.Name = "lb_Trimestre";
            this.lb_Trimestre.Size = new System.Drawing.Size(50, 13);
            this.lb_Trimestre.TabIndex = 7;
            this.lb_Trimestre.Text = "Trimestre";
            // 
            // lb_Quantidade
            // 
            this.lb_Quantidade.AutoSize = true;
            this.lb_Quantidade.Location = new System.Drawing.Point(490, 9);
            this.lb_Quantidade.Name = "lb_Quantidade";
            this.lb_Quantidade.Size = new System.Drawing.Size(170, 13);
            this.lb_Quantidade.TabIndex = 8;
            this.lb_Quantidade.Text = "Quantidade de horas a compensar";
            // 
            // lb_Disciplina
            // 
            this.lb_Disciplina.AutoSize = true;
            this.lb_Disciplina.Location = new System.Drawing.Point(233, 9);
            this.lb_Disciplina.Name = "lb_Disciplina";
            this.lb_Disciplina.Size = new System.Drawing.Size(52, 13);
            this.lb_Disciplina.TabIndex = 10;
            this.lb_Disciplina.Text = "Disciplina";
            // 
            // numUpDown_Quantidade
            // 
            this.numUpDown_Quantidade.Location = new System.Drawing.Point(493, 25);
            this.numUpDown_Quantidade.Name = "numUpDown_Quantidade";
            this.numUpDown_Quantidade.Size = new System.Drawing.Size(63, 20);
            this.numUpDown_Quantidade.TabIndex = 12;
            // 
            // cbb_Disciplina
            // 
            this.cbb_Disciplina.FormattingEnabled = true;
            this.cbb_Disciplina.Location = new System.Drawing.Point(236, 25);
            this.cbb_Disciplina.Name = "cbb_Disciplina";
            this.cbb_Disciplina.Size = new System.Drawing.Size(103, 21);
            this.cbb_Disciplina.TabIndex = 13;
            // 
            // bttInserir
            // 
            this.bttInserir.Location = new System.Drawing.Point(566, 461);
            this.bttInserir.Name = "bttInserir";
            this.bttInserir.Size = new System.Drawing.Size(110, 36);
            this.bttInserir.TabIndex = 1;
            this.bttInserir.Text = "Inserir";
            this.bttInserir.UseVisualStyleBackColor = true;
            this.bttInserir.Click += new System.EventHandler(this.bttInserir_Click);
            // 
            // RegistarHorasACompensar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(688, 509);
            this.Controls.Add(this.cbb_Disciplina);
            this.Controls.Add(this.numUpDown_Quantidade);
            this.Controls.Add(this.lb_Disciplina);
            this.Controls.Add(this.lb_Quantidade);
            this.Controls.Add(this.lb_Trimestre);
            this.Controls.Add(this.tbx_Trimestre);
            this.Controls.Add(this.tbx_Turma);
            this.Controls.Add(this.lb_Turma);
            this.Controls.Add(this.lstview_Turma);
            this.Controls.Add(this.bttInserir);
            this.Name = "RegistarHorasACompensar";
            this.Text = "RegistarHorasACompensar";
            ((System.ComponentModel.ISupportInitialize)(this.numUpDown_Quantidade)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ListView lstview_Turma;
        private System.Windows.Forms.Label lb_Turma;
        private System.Windows.Forms.TextBox tbx_Turma;
        private System.Windows.Forms.ColumnHeader Codigo;
        private System.Windows.Forms.ColumnHeader codigodaturma;
        private System.Windows.Forms.ColumnHeader Nome;
        private System.Windows.Forms.TextBox tbx_Trimestre;
        private System.Windows.Forms.Label lb_Trimestre;
        private System.Windows.Forms.Label lb_Quantidade;
        private System.Windows.Forms.Label lb_Disciplina;
        private System.Windows.Forms.NumericUpDown numUpDown_Quantidade;
        private System.Windows.Forms.ComboBox cbb_Disciplina;
        private System.Windows.Forms.Button bttInserir;
    }
}